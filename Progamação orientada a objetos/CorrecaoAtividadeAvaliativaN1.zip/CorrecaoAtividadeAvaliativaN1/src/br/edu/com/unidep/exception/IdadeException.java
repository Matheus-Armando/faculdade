package br.edu.com.unidep.exception;

public class IdadeException extends Exception {

	private static final long serialVersionUID = 1L;

	public IdadeException(String message) {
		super(message);
	}
	
	

}
