package br.edu.unidep.model;

public class ExemploVariavel {
	
	public static void main(String[] args) {
		
		String mensagem = "Teste!!!";
		byte idadeDaPessoa = 75;

		
		System.out.println(mensagem + " - " + idadeDaPessoa);
	}
	
}