package br.edu.unidep.bancario.modelo;

public interface Operacao {
	
	public double calcularJuros(double valor);

}
